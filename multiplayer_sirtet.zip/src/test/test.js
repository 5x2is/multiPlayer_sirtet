'use strict';
console.log(process.argv[0]);
const array = new Array(2);
array[0] = {
    aa: 0,
    bb: 1
};
if(array[0]){
    console.log('true1');
}
if(array[1]){
    console.log('true2');
}

